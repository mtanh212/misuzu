// init search table
$(function() {
    oTable = $('#joutaimaster').DataTable({
        "pagingType": "simple_numbers"
        , "oLanguage": {
            "sUrl": "../../assets/resource/dataTable_ja.txt"
        }
    });
});

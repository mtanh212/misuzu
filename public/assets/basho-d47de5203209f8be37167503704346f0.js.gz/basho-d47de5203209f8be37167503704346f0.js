// init search table
$(function() {
    oTable = $('#bashomaster').DataTable({
        "pagingType": "simple_numbers"
        , "oLanguage": {
            "sUrl": "../../assets/resource/dataTable_ja.txt"
        }
    });
});
